import { useEffect, useState } from 'react';
import {
  Users, UserPlus, Phone, FileText, FolderKanban, Bell, ClipboardCheck, TrendingUp,
  CheckCircle2, XCircle, IndianRupee, Plus,
} from 'lucide-react';
import { useData } from '@/data/DataContext';
import { useAuth } from '@/data/AuthContext';
import { PortalLayout, PageContainer, PageHeader } from '@/components/layout/PortalLayout';
import { KpiCard } from '@/components/ui/KpiCard';
import { DataTable } from '@/components/ui/DataTable';
import { Modal } from '@/components/ui/Modal';
import { StatusBadge, StatusBadgeAuto, AlertBanner } from '@/components/ui/Status';
import { fmtINR, fmtDate } from '@/lib/format';
import { useWorkflow } from '@/data/WorkflowContext';

export function SalesPortal() {
  const [active, setActive] = useState('dashboard');
  return (
    <PortalLayout active={active} onNavigate={setActive}>
      <SalesPage active={active} onNavigate={setActive} />
    </PortalLayout>
  );
}

function SalesPage({ active, onNavigate }) {
  switch (active) {
    case 'dashboard': return <SalesDashboard onNavigate={onNavigate} />;
    case 'enquiries': return <EnquiriesPage />;
    case 'leads': return <LeadsPage />;
    case 'directory': return <DirectoryPage />;
    case 'followups': return <FollowupsPage />;
    case 'survey-requests': return <SurveyRequestsPage />;
    case 'solar-configuration': return <SolarConfigPage />;
    case 'quotations': return <SalesQuotationsPage />;
    case 'my-projects': return <MyProjectsPage />;
    case 'notifications': return <NotificationsPage />;
    default: return <SalesDashboard onNavigate={onNavigate} />;
  }
}

function SalesDashboard({ onNavigate }) {
  const { customers, projects, surveys, quotations } = useWorkflow();
  const { user } = useAuth();
  const myLeads = customers.filter((c) => c.assignedTo === user?.name);
  const newEnquiries = myLeads.filter((c) => c.leadStatus === 'New' || c.leadStatus === 'Contacted');
  const surveysPending = surveys.filter((s) => s.status === 'Scheduled');
  const surveysDone = surveys.filter((s) => s.status === 'Approved');
  const quotesPending = quotations.filter((q) => q.status === 'Sent');
  const won = myLeads.filter((c) => c.leadStatus === 'Won');
  const lost = myLeads.filter((c) => c.leadStatus === 'Lost');

  return (
    <PageContainer>
      <PageHeader title="Sales Dashboard" description={`Welcome back, ${user?.name}. Here's your lead pipeline and project activity.`} />
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-6">
        <KpiCard label="New Enquiries" value={newEnquiries.length} icon={UserPlus} tone="navy" onClick={() => onNavigate('enquiries')} />
        <KpiCard label="Leads Assigned" value={myLeads.length} icon={Users} tone="grape" onClick={() => onNavigate('leads')} />
        <KpiCard label="Surveys Pending" value={surveysPending.length} icon={ClipboardCheck} tone="amber" onClick={() => onNavigate('survey-requests')} />
        <KpiCard label="Surveys Completed" value={surveysDone.length} icon={CheckCircle2} tone="emerald" />
        <KpiCard label="Quotes Awaiting Approval" value={quotesPending.length} icon={FileText} tone="navy" onClick={() => onNavigate('quotations')} />
        <KpiCard label="Converted Customers" value={won.length} icon={TrendingUp} tone="emerald" onClick={() => onNavigate('my-projects')} />
        <KpiCard label="Lost Leads" value={lost.length} icon={XCircle} tone="rose" />
        <KpiCard label="Active Projects" value={projects.filter((p) => !['Completed', 'Handed Over'].includes(p.status)).length} icon={FolderKanban} tone="navy" onClick={() => onNavigate('my-projects')} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        <div className="card p-5">
          <h3 className="section-title mb-3">Lead Pipeline</h3>
          <div className="space-y-2.5">
            {(['New', 'Contacted', 'Survey Scheduled', 'Quoted', 'Won', 'Lost']).map((stage) => {
              const count = myLeads.filter((c) => c.leadStatus === stage).length;
              const pct = myLeads.length ? (count / myLeads.length) * 100 : 0;
              return (
                <div key={stage}>
                  <div className="flex items-center justify-between text-xs mb-1">
                    <span className="text-slate-600">{stage}</span>
                    <span className="font-semibold text-navy-700">{count}</span>
                  </div>
                  <div className="h-1.5 bg-slate-100 rounded-full overflow-hidden">
                    <div className={`h-full rounded-full ${stage === 'Won' ? 'bg-emerald-500' : stage === 'Lost' ? 'bg-rose-400' : 'bg-navy-500'}`} style={{ width: `${pct}%` }} />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        <div className="card p-5">
          <h3 className="section-title mb-3">Recent Interactions</h3>
          <div className="space-y-2">
            {customers.flatMap((c) => (c.interactions || []).map((i) => ({ ...i, customer: c.name }))).slice(0, 6).map((i) => (
              <div key={i.id} className="flex items-start gap-3 text-sm">
                <div className="w-7 h-7 rounded-full bg-navy-50 text-navy-600 flex items-center justify-center shrink-0"><Phone className="w-3.5 h-3.5" /></div>
                <div>
                  <div className="font-medium text-navy-800">{i.customer}</div>
                  <div className="text-xs text-slate-500">{i.note}</div>
                  <div className="text-xs text-slate-400">{fmtDate(i.date)} · {i.type}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </PageContainer>
  );
}

function EnquiriesPage() {
  const { customers, loading, error, request, refresh } = useWorkflow();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ name: '', email: '', phone: '', city: '', consumption: 0, bill: 0, capacity: 3, source: 'Website' });
  const [actionError, setActionError] = useState('');

  const create = async () => {
    if (!form.name || !form.phone) return;
    setActionError('');
    try {
      await request('/workflow/enquiries', {
        method: 'POST',
        body: JSON.stringify({
          name: form.name,
          email: form.email,
          phone: form.phone,
          city: form.city,
          electricityConsumption: form.consumption,
          monthlyBill: form.bill,
          desiredCapacity: form.capacity,
          enquirySource: form.source,
        }),
      });
      await refresh();
      setOpen(false);
      setForm({ name: '', email: '', phone: '', city: '', consumption: 0, bill: 0, capacity: 3, source: 'Website' });
    } catch (createError) {
      setActionError(createError.message || 'Could not create enquiry.');
    }
  };

  const columns = [
    { key: 'code', label: 'Code', sortValue: (r) => r.code, render: (r) => <span className="font-mono text-xs text-slate-500">{r.code}</span> },
    { key: 'name', label: 'Customer', sortValue: (r) => r.name, render: (r) => <div><div className="font-medium text-navy-800">{r.name}</div><div className="text-xs text-slate-400">{r.city}</div></div> },
    { key: 'phone', label: 'Phone', render: (r) => r.phone },
    { key: 'capacity', label: 'Desired kW', sortValue: (r) => r.desiredCapacity, render: (r) => `${r.desiredCapacity} kW` },
    { key: 'bill', label: 'Monthly Bill', sortValue: (r) => r.monthlyBill, render: (r) => fmtINR(r.monthlyBill) },
    { key: 'source', label: 'Source', render: (r) => r.enquirySource },
    { key: 'leadStatus', label: 'Status', sortValue: (r) => r.leadStatus, render: (r) => <StatusBadgeAuto status={r.leadStatus} /> },
  ];

  return (
    <PageContainer>
      <PageHeader title="Customer Enquiries" description="Register new customer enquiries and track initial contact." actions={<button className="btn-primary" onClick={() => setOpen(true)}><Plus className="w-4 h-4" />New Enquiry</button>} />
      {error && <div className="card p-3 mb-3 bg-rose-50 text-sm text-rose-700">{error}</div>}
      {actionError && <div className="card p-3 mb-3 bg-rose-50 text-sm text-rose-700">{actionError}</div>}
      {loading ? <div className="card p-8 text-center text-slate-500">Loading enquiries...</div> : <DataTable columns={columns} rows={customers} searchKeys={['name', 'phone', 'city']} searchPlaceholder="Search enquiries..." />}
      <Modal open={open} onClose={() => setOpen(false)} title="New Customer Enquiry" description="Register a new solar enquiry and assign it to yourself."
        footer={<><button className="btn-outline" onClick={() => setOpen(false)}>Cancel</button><button className="btn-primary" onClick={create}>Create Enquiry</button></>}>
        <div className="grid grid-cols-2 gap-3">
          <div><label className="label">Full Name *</label><input className="input" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></div>
          <div><label className="label">Phone *</label><input className="input" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} /></div>
          <div><label className="label">Email</label><input className="input" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} /></div>
          <div><label className="label">City</label><input className="input" value={form.city} onChange={(e) => setForm({ ...form, city: e.target.value })} /></div>
          <div><label className="label">Monthly Consumption (kWh)</label><input type="number" className="input" value={form.consumption} onChange={(e) => setForm({ ...form, consumption: Number(e.target.value) })} /></div>
          <div><label className="label">Monthly Bill (₹)</label><input type="number" className="input" value={form.bill} onChange={(e) => setForm({ ...form, bill: Number(e.target.value) })} /></div>
          <div><label className="label">Desired Capacity (kW)</label><input type="number" className="input" value={form.capacity} onChange={(e) => setForm({ ...form, capacity: Number(e.target.value) })} /></div>
          <div><label className="label">Lead Source</label><select className="input" value={form.source} onChange={(e) => setForm({ ...form, source: e.target.value })}><option>Website</option><option>Referral</option><option>Advertisement</option><option>Exhibition</option></select></div>
        </div>
      </Modal>
    </PageContainer>
  );
}

function LeadsPage() {
  const { customers } = useWorkflow();
  const { user } = useAuth();
  const myLeads = customers.filter((c) => c.assignedTo === user?.name);
  const columns = [
    { key: 'code', label: 'Code', render: (r) => <span className="font-mono text-xs text-slate-500">{r.code}</span> },
    { key: 'name', label: 'Lead', sortValue: (r) => r.name, render: (r) => <div className="font-medium text-navy-800">{r.name}</div> },
    { key: 'source', label: 'Source', render: (r) => r.enquirySource },
    { key: 'capacity', label: 'Target', render: (r) => `${r.desiredCapacity} kW` },
    { key: 'bill', label: 'Bill', render: (r) => fmtINR(r.monthlyBill) },
    { key: 'leadStatus', label: 'Status', sortValue: (r) => r.leadStatus, render: (r) => <StatusBadgeAuto status={r.leadStatus} /> },
    { key: 'createdAt', label: 'Created', sortValue: (r) => r.createdAt, render: (r) => fmtDate(r.createdAt) },
  ];
  return (
    <PageContainer>
      <PageHeader title="Lead Management" description="Leads assigned to you — track status and progression." />
      <DataTable columns={columns} rows={myLeads} searchKeys={['name']} searchPlaceholder="Search leads..." />
    </PageContainer>
  );
}

function DirectoryPage() {
  const { customers } = useWorkflow();
  const columns = [
    { key: 'code', label: 'Code', render: (r) => <span className="font-mono text-xs text-slate-500">{r.code}</span> },
    { key: 'name', label: 'Customer', sortValue: (r) => r.name, render: (r) => <div className="font-medium text-navy-800">{r.name}</div> },
    { key: 'phone', label: 'Phone', render: (r) => r.phone },
    { key: 'city', label: 'City', render: (r) => `${r.city}, ${r.state}` },
    { key: 'leadStatus', label: 'Status', sortValue: (r) => r.leadStatus, render: (r) => <StatusBadgeAuto status={r.leadStatus} /> },
  ];
  return (
    <PageContainer>
      <PageHeader title="Customer Directory" description="All customer records with contact details." />
      <DataTable columns={columns} rows={customers} searchKeys={['name', 'phone', 'city']} searchPlaceholder="Search customers..." />
    </PageContainer>
  );
}

function FollowupsPage() {
  const { customers, request, refresh } = useWorkflow();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ customerId: '', type: 'Call', note: '' });
  const [error, setError] = useState('');

  const add = async () => {
    if (!form.customerId || !form.note) return;
    setError('');
    try {
      await request(`/workflow/enquiries/${form.customerId}/followups`, {
        method: 'POST',
        body: JSON.stringify({ type: form.type, note: form.note }),
      });
      await refresh();
      setOpen(false);
      setForm({ customerId: '', type: 'Call', note: '' });
    } catch (saveError) {
      setError(saveError.message || 'Could not save follow-up.');
    }
  };

  return (
    <PageContainer>
      <PageHeader title="Follow-ups & Meetings" description="Track customer interactions and scheduled follow-ups." actions={<button className="btn-primary" onClick={() => setOpen(true)}><Plus className="w-4 h-4" />Log Follow-up</button>} />
      <div className="space-y-2">
        {error && <div className="card p-3 text-sm text-rose-700 bg-rose-50">{error}</div>}
        {customers.flatMap((c) => (c.interactions || []).map((i) => ({ ...i, customer: c.name, code: c.code }))).sort((a, b) => b.date.localeCompare(a.date)).map((i) => (
          <div key={i.id} className="card p-3 flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-navy-50 text-navy-600 flex items-center justify-center"><Phone className="w-4 h-4" /></div>
            <div className="flex-1 min-w-0">
              <div className="font-medium text-navy-800 text-sm">{i.customer}</div>
              <div className="text-xs text-slate-500">{i.note}</div>
            </div>
            <div className="text-right text-xs text-slate-400">{i.type} · {fmtDate(i.date)}</div>
          </div>
        ))}
      </div>
      <Modal open={open} onClose={() => setOpen(false)} title="Log Follow-up" footer={<><button className="btn-outline" onClick={() => setOpen(false)}>Cancel</button><button className="btn-primary" onClick={add}>Save</button></>}>
        <div className="space-y-3">
          <div><label className="label">Customer</label><select className="input" value={form.customerId} onChange={(e) => setForm({ ...form, customerId: e.target.value })}><option value="">Select...</option>{customers.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}</select></div>
          <div><label className="label">Type</label><select className="input" value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value })}><option>Call</option><option>Email</option><option>Visit</option><option>WhatsApp</option></select></div>
          <div><label className="label">Notes</label><textarea className="input" rows={3} value={form.note} onChange={(e) => setForm({ ...form, note: e.target.value })} /></div>
        </div>
      </Modal>
    </PageContainer>
  );
}

function SurveyRequestsPage() {
  const { customers, projects, surveys, error, loading } = useWorkflow();
  return (
    <PageContainer>
      <PageHeader title="Roof Survey Requests" description="Track survey scheduling status for your customers." />
      <div className="space-y-2">
        {error && <div className="card p-3 text-sm text-rose-700 bg-rose-50">{error}</div>}
        {loading ? <div className="card p-8 text-center text-slate-500">Loading surveys...</div> : surveys.map((s) => {
          const proj = projects.find((p) => p.id === s.projectId);
          const cust = customers.find((c) => c.id === s.customerId);
          return (
            <div key={s.id} className="card p-4 flex items-center justify-between gap-3 flex-wrap">
              <div>
                <div className="font-medium text-navy-800">{cust?.name}</div>
                <div className="text-xs text-slate-500">{proj?.code} · Scheduled {fmtDate(s.scheduledDate)}</div>
              </div>
              <div className="flex items-center gap-3">
                <span className="text-xs text-slate-500">{s.assignedTo}</span>
                <StatusBadgeAuto status={s.status} />
              </div>
            </div>
          );
        })}
      </div>
    </PageContainer>
  );
}

function SolarConfigPage() {
  return <SolarConfigEmbed />;
}

import { SolarConfigurationIntelligence } from '@/pages/SolarConfigurationIntelligence';
function SolarConfigEmbed() { return <SolarConfigurationIntelligence />; }

function SalesQuotationsPage() {
  const { projects, customers, quotations } = useWorkflow();
  const columns = [
    { key: 'code', label: 'Code', sortValue: (r) => r.code, render: (r) => <span className="font-mono text-xs text-slate-500">{r.code}</span> },
    { key: 'project', label: 'Project / Customer', sortValue: (r) => r.code, render: (r) => { const p = projects.find((p) => p.id === r.projectId); const c = customers.find((c) => c.id === r.customerId); return <div><div className="font-medium text-navy-800">{p?.code}</div><div className="text-xs text-slate-400">{c?.name}</div></div>; } },
    { key: 'total', label: 'Total', sortValue: (r) => r.total, render: (r) => fmtINR(r.total) },
    { key: 'status', label: 'Status', sortValue: (r) => r.status, render: (r) => <StatusBadgeAuto status={r.status} /> },
    { key: 'createdAt', label: 'Created', sortValue: (r) => r.createdAt, render: (r) => fmtDate(r.createdAt) },
  ];
  return (
    <PageContainer>
      <PageHeader title="Quotations" description="Generate and send quotations to customers for approval." />
      <DataTable columns={columns} rows={quotations} searchKeys={['code']} searchPlaceholder="Search quotations..." />
    </PageContainer>
  );
}

function MyProjectsPage() {
  const { projects, customers, surveys, request, refresh } = useWorkflow();
  const { user } = useAuth();
  const [surveyors, setSurveyors] = useState([]);
  const [assignment, setAssignment] = useState(null);
  const [createOpen, setCreateOpen] = useState(false);
  const [projectForm, setProjectForm] = useState({ customerId: '', capacity: 3, gridType: 'On-Grid', location: '' });
  const [assignmentForm, setAssignmentForm] = useState({ technicianId: '', scheduledDate: new Date().toISOString().slice(0, 10), remarks: '' });
  const [savingAssignment, setSavingAssignment] = useState(false);
  const [savingProject, setSavingProject] = useState(false);
  const [assignmentError, setAssignmentError] = useState('');
  const [projectError, setProjectError] = useState('');

  const myProjects = projects.filter((p) => p.assignedTo === user?.name || user?.role === 'Admin');

  const getProjectSurvey = (project) => surveys.find((survey) => String(survey.projectId) === String(project.id));

  const loadSurveyors = async () => {
    try {
      const result = await request('/workflow/surveyors');
      setSurveyors(result.surveyors || []);
    } catch (err) {
      setSurveyors([]);
    }
  };

  useEffect(() => {
    loadSurveyors();
  }, [request]);

  const getStatusBadge = (survey) => {
    const surveyStatus = !survey ? 'Not Assigned' : survey.status === 'Scheduled' ? 'Assigned' : survey.status;
    const variant = !survey ? 'slate' : survey.status === 'Approved' ? 'emerald' : survey.status === 'Rejected' ? 'rose' : survey.status === 'Submitted' ? 'amber' : survey.status === 'In Progress' ? 'navy' : survey.status === 'Scheduled' ? 'amber' : 'slate';
    return <StatusBadge status={surveyStatus} variant={variant} />;
  };

  const openAssignment = (project) => {
    const survey = getProjectSurvey(project);
    setAssignment(project);
    setAssignmentError('');
    setAssignmentForm({
      technicianId: survey?.technicianId || '',
      scheduledDate: survey?.scheduledDate || new Date().toISOString().slice(0, 10),
      remarks: survey?.remarks || '',
    });
  };

  const saveProject = async () => {
    if (!projectForm.customerId) {
      setProjectError('Choose a customer before creating the project.');
      return;
    }

    setSavingProject(true);
    setProjectError('');
    try {
      await request('/workflow/projects', {
        method: 'POST',
        body: JSON.stringify({
          customerId: projectForm.customerId,
          capacity: projectForm.capacity,
          gridType: projectForm.gridType,
          location: projectForm.location,
        }),
      });
      await refresh();
      setCreateOpen(false);
      setProjectForm({ customerId: '', capacity: 3, gridType: 'On-Grid', location: '' });
    } catch (saveError) {
      setProjectError(saveError.message || 'Could not create project.');
    } finally {
      setSavingProject(false);
    }
  };

  const saveAssignment = async () => {
    if (!assignment || !assignmentForm.technicianId || !assignmentForm.scheduledDate) {
      setAssignmentError('Select a survey technician and a date before saving.');
      return;
    }

    setSavingAssignment(true);
    setAssignmentError('');
    try {
      const survey = getProjectSurvey(assignment);
      await request(`/workflow/projects/${assignment.id}/surveys`, {
        method: 'POST',
        body: JSON.stringify({
          technicianId: assignmentForm.technicianId,
          scheduledDate: assignmentForm.scheduledDate,
          remarks: assignmentForm.remarks,
          reassign: !!survey && ['Scheduled', 'In Progress', 'Submitted'].includes(survey.status),
        }),
      });
      await refresh();
      setAssignment(null);
    } catch (saveError) {
      setAssignmentError(saveError.message || 'Could not assign the survey.');
    } finally {
      setSavingAssignment(false);
    }
  };

  const columns = [
    { key: 'code', label: 'Code', render: (r) => <span className="font-mono text-xs text-slate-500">{r.code}</span> },
    { key: 'customer', label: 'Customer', sortValue: (r) => r.code, render: (r) => { const c = customers.find((c) => c.id === r.customerId); return <span className="font-medium text-navy-800">{c?.name}</span>; } },
    { key: 'capacity', label: 'Capacity', render: (r) => `${r.capacity} kW ${r.gridType}` },
    { key: 'surveyStatus', label: 'Survey Status', sortValue: (r) => getProjectSurvey(r)?.status || 'Not Assigned', render: (r) => getStatusBadge(getProjectSurvey(r)) },
    { key: 'assignedSurveyTechnician', label: 'Assigned Survey Technician', render: (r) => { const survey = getProjectSurvey(r); return survey?.assignedTo || '—'; } },
    { key: 'scheduledSurveyDate', label: 'Scheduled Survey Date', render: (r) => { const survey = getProjectSurvey(r); return survey?.scheduledDate ? fmtDate(survey.scheduledDate) : '—'; } },
    { key: 'completion', label: 'Progress', sortValue: (r) => r.completion, render: (r) => <span className="badge-navy">{r.completion}%</span> },
    { key: 'status', label: 'Project Status', sortValue: (r) => r.status, render: (r) => <StatusBadgeAuto status={r.status} /> },
    { key: 'action', label: 'Action', render: (r) => { const survey = getProjectSurvey(r); const label = survey ? ['Scheduled', 'In Progress', 'Submitted'].includes(survey.status) ? 'Reassign Survey' : 'Assign Survey' : 'Assign Survey'; return <button className="btn-outline btn-sm" onClick={(e) => { e.stopPropagation(); openAssignment(r); }}>{label}</button>; } },
  ];

  return (
    <PageContainer>
      <PageHeader title="My Projects" description="Projects you are responsible for." actions={<button className="btn-primary" onClick={() => setCreateOpen(true)}><Plus className="w-4 h-4" />Create Project</button>} />
      {myProjects.length === 0 && (
        <div className="card p-6 text-center">
          <div className="text-slate-500 mb-3">No projects yet. Create the first project for the customer request, then assign a survey technician.</div>
          <button className="btn-primary" onClick={() => setCreateOpen(true)}><Plus className="w-4 h-4" />Create Project</button>
        </div>
      )}
      {myProjects.length > 0 && <DataTable columns={columns} rows={myProjects} searchKeys={['code']} searchPlaceholder="Search projects..." />}
      <Modal open={createOpen} onClose={() => setCreateOpen(false)} title="Create Project" description="Create a project from a customer request before assigning a survey technician." footer={<><button className="btn-outline" onClick={() => setCreateOpen(false)}>Cancel</button><button className="btn-primary" onClick={saveProject} disabled={savingProject}>{savingProject ? 'Creating...' : 'Create Project'}</button></>}>
        <div className="space-y-3">
          {projectError && <div className="card p-3 text-sm text-rose-700 bg-rose-50">{projectError}</div>}
          <div>
            <label className="label">Customer</label>
            <select className="input" value={projectForm.customerId} onChange={(e) => setProjectForm({ ...projectForm, customerId: e.target.value })}>
              <option value="">Select customer</option>
              {customers.map((customer) => <option key={customer.id} value={customer.id}>{customer.name} · {customer.city}</option>)}
            </select>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="label">Capacity (kW)</label>
              <input type="number" className="input" value={projectForm.capacity} onChange={(e) => setProjectForm({ ...projectForm, capacity: Number(e.target.value) || 3 })} />
            </div>
            <div>
              <label className="label">Grid Type</label>
              <select className="input" value={projectForm.gridType} onChange={(e) => setProjectForm({ ...projectForm, gridType: e.target.value })}>
                <option>On-Grid</option>
                <option>Off-Grid</option>
                <option>Hybrid</option>
              </select>
            </div>
          </div>
          <div>
            <label className="label">Location</label>
            <input className="input" value={projectForm.location} onChange={(e) => setProjectForm({ ...projectForm, location: e.target.value })} placeholder="City, State" />
          </div>
        </div>
      </Modal>
      <Modal open={!!assignment} onClose={() => setAssignment(null)} title="Assign Survey" description="Select a surveyor and schedule the technical site visit." footer={<><button className="btn-outline" onClick={() => setAssignment(null)}>Cancel</button><button className="btn-primary" onClick={saveAssignment} disabled={savingAssignment}>{savingAssignment ? 'Saving...' : 'Save Assignment'}</button></>}>
        <div className="space-y-3">
          {assignmentError && <div className="card p-3 text-sm text-rose-700 bg-rose-50">{assignmentError}</div>}
          <div>
            <label className="label">Survey Technician</label>
            <select className="input" value={assignmentForm.technicianId} onChange={(e) => setAssignmentForm({ ...assignmentForm, technicianId: e.target.value })}>
              <option value="">Select survey technician</option>
              {surveyors.map((tech) => <option key={tech.id} value={tech.id}>{tech.name} · {tech.email}</option>)}
            </select>
          </div>
          <div>
            <label className="label">Scheduled Date</label>
            <input type="date" className="input" value={assignmentForm.scheduledDate} onChange={(e) => setAssignmentForm({ ...assignmentForm, scheduledDate: e.target.value })} />
          </div>
          <div>
            <label className="label">Remarks</label>
            <textarea className="input" rows={3} value={assignmentForm.remarks} onChange={(e) => setAssignmentForm({ ...assignmentForm, remarks: e.target.value })} placeholder="Site notes or customer requirements" />
          </div>
        </div>
      </Modal>
    </PageContainer>
  );
}

function NotificationsPage() {
  const { data } = useData();
  return (
    <PageContainer>
      <PageHeader title="Notifications" description="Alerts and updates relevant to your role." />
      <div className="space-y-2">
        {data.notifications.map((n) => (
          <div key={n.id} className={`card p-4 flex items-start gap-3 ${!n.read ? 'border-l-4 border-l-emerald-500' : ''}`}>
            <div className="w-9 h-9 rounded-lg bg-navy-50 text-navy-600 flex items-center justify-center"><Bell className="w-4 h-4" /></div>
            <div className="flex-1"><div className="font-medium text-navy-800 text-sm">{n.title}</div><div className="text-xs text-slate-500 mt-0.5">{n.message}</div><div className="text-xs text-slate-400 mt-1">{n.time}</div></div>
          </div>
        ))}
      </div>
    </PageContainer>
  );
}
