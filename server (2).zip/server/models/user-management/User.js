import mongoose from 'mongoose';
import bcrypt from 'bcryptjs';

const userSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: [true, 'Name is required'],
      trim: true,
    },
    email: {
      type: String,
      required: [true, 'Email is required'],
      unique: true,
      lowercase: true,
      trim: true,
    },
    password: {
      type: String,
      required: [true, 'Password is required'],
      minlength: 6,
      select: false,
    },
    role: {
      type: String,
      enum: ['Admin', 'Client', 'Customer', 'Sales', 'Surveyor', 'SURVEY_TECHNICIAN', 'Warehouse', 'Technician', 'INSTALLATION_TECHNICIAN', 'Service', 'Finance'],
      default: 'Client',
    },
    phone: {
      type: String,
      default: '',
    },
    companyName: {
      type: String,
      default: '',
    },
    customerId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Customer',
      default: null,
    },
    isActive: {
      type: Boolean,
      default: true,
    },
  },
  {
    timestamps: true,
  }
);

userSchema.pre('validate', function normalizeRole(next) {
  if (this.role === 'Surveyor') this.role = 'SURVEY_TECHNICIAN';
  if (this.role === 'Technician') this.role = 'INSTALLATION_TECHNICIAN';
  next();
});

userSchema.pre('save', async function hashPassword(next) {
  if (!this.isModified('password')) return next();

  this.password = await bcrypt.hash(this.password, 12);
  next();
});

userSchema.methods.comparePassword = async function comparePassword(candidatePassword) {
  return bcrypt.compare(candidatePassword, this.password);
};

const User = mongoose.model('User', userSchema);

export default User;